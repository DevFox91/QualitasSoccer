package com.ojeda.QualitasSoccer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QualitasSoccerApplication {

	public static void main(String[] args) {
		SpringApplication.run(QualitasSoccerApplication.class, args);
	}

}
