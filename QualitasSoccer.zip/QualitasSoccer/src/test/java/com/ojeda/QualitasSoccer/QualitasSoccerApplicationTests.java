package com.ojeda.QualitasSoccer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QualitasSoccerApplicationTests {

	@Test
	void contextLoads() {
	}

}
